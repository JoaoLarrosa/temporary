console.log("a")

document.body.insertAdjacentHTML("beforeend", `

    <iframe
        src="http://34.95.248.194/noBubble"
        frameBorder="0"
        height="520px"
        width="350px"
        id="Max"
    >
    </iframe>

`)