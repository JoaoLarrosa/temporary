const bt = document.querySelector("button#close")

bt.addEventListener("click", () => {

    window.close()

})