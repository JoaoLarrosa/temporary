let aberto = false

let idWin = 0

chrome.browserAction.onClicked.addListener((tab) => {
    
    console.log("click")

    if (aberto) {

        chrome.windows.remove(idWin, () => {

            idWin = 0

            aberto = false

        })

    }
    else {

        chrome.windows.create({
            url: chrome.runtime.getURL("index.html"),
            type: "popup",
            width: 440,
            height: 628,
            focused: true,
            setSelfAsOpener: true
        }, (window) => {

            console.log("Window ID:", window.id)

            idWin = window.id

            aberto = true

        });

    }

});

chrome.windows.onRemoved.addListener((id) => {

    if (id == idWin) {

        aberto = false

        idWin = 0

    }

})